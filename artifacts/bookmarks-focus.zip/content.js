"use strict";
(() => {
  // src/utils.ts
  var BOOKMARKS_PATH = "/i/bookmarks";
  var ALLOWED_URL_PATTERN = /^\/[^/]+\/(status|article)\/\d+/;
  function isOnAllowedPage(pathname) {
    return pathname.startsWith(BOOKMARKS_PATH) || ALLOWED_URL_PATTERN.test(pathname);
  }

  // src/content.ts
  var FOCUS_STYLES = `
  /* Right sidebar: trending, "Who to follow", search suggestions */
  [data-testid="sidebarColumn"] { display: none !important; }

  /* Left nav: hide every item except the Bookmarks link */
  nav[aria-label="Primary"] > *:not(a[href="/i/bookmarks"]) {
    display: none !important;
  }

  /* Post / Tweet button */
  [data-testid="SideNav_NewTweet_Button"] { display: none !important; }
`;
  var styleEl = null;
  var observer = null;
  var previousPath = window.location.pathname;
  function injectStyles() {
    if (styleEl) return;
    styleEl = document.createElement("style");
    styleEl.id = "x-bookmarks-focus-styles";
    styleEl.textContent = FOCUS_STYLES;
    (document.head ?? document.documentElement).appendChild(styleEl);
  }
  function removeStyles() {
    styleEl?.remove();
    styleEl = null;
  }
  function applyFocusMode() {
    if (!isOnAllowedPage(window.location.pathname)) {
      window.location.replace(BOOKMARKS_PATH);
    }
  }
  var originalPushState = history.pushState.bind(history);
  var originalReplaceState = history.replaceState.bind(history);
  function onPopState() {
    previousPath = window.location.pathname;
    applyFocusMode();
  }
  function setupObserver() {
    if (observer) return;
    observer = new MutationObserver(() => {
      const currentPath = window.location.pathname;
      if (currentPath !== previousPath) {
        previousPath = currentPath;
        applyFocusMode();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("popstate", onPopState);
    history.pushState = function(...args) {
      originalPushState(...args);
      previousPath = window.location.pathname;
      applyFocusMode();
    };
    history.replaceState = function(...args) {
      originalReplaceState(...args);
      previousPath = window.location.pathname;
      applyFocusMode();
    };
  }
  function teardownObserver() {
    if (!observer) return;
    observer.disconnect();
    observer = null;
    window.removeEventListener("popstate", onPopState);
    history.pushState = originalPushState;
    history.replaceState = originalReplaceState;
  }
  function enable() {
    injectStyles();
    applyFocusMode();
    setupObserver();
  }
  function disable() {
    teardownObserver();
    removeStyles();
  }
  chrome.runtime.onMessage.addListener(
    (message) => {
      if (message.type === "SET_ENABLED") {
        if (message.enabled) {
          enable();
        } else {
          disable();
        }
      }
    }
  );
  chrome.storage.sync.get({ enabled: true }, ({ enabled }) => {
    if (enabled) enable();
  });
})();
