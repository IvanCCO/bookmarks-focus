"use strict";
(() => {
  // src/background.ts
  chrome.runtime.onInstalled.addListener(({ reason }) => {
    if (reason === chrome.runtime.OnInstalledReason.INSTALL) {
      console.log("[X Bookmarks Focus] Extension installed.");
    } else if (reason === chrome.runtime.OnInstalledReason.UPDATE) {
      console.log("[X Bookmarks Focus] Extension updated.");
    }
  });
})();
