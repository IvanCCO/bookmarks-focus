"use strict";
(() => {
  // src/popup.ts
  var toggleBtn = document.getElementById("toggle");
  var labelEl = document.getElementById("label");
  var statusEl = document.getElementById("status");
  async function getEnabled() {
    const result = await chrome.storage.sync.get({ enabled: true });
    return result["enabled"];
  }
  function renderState(enabled) {
    if (enabled) {
      toggleBtn.className = "is-enabled";
      labelEl.textContent = "Enabled";
      statusEl.textContent = "Redirecting to bookmarks \xB7 hiding distractions";
    } else {
      toggleBtn.className = "is-disabled";
      labelEl.textContent = "Disabled";
      statusEl.textContent = "Extension is paused \xB7 X works normally";
    }
  }
  async function notifyActiveTab(enabled) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id == null) return;
    chrome.tabs.sendMessage(tab.id, { type: "SET_ENABLED", enabled }).catch(() => {
    });
  }
  async function onToggle() {
    const current = await getEnabled();
    const next = !current;
    await chrome.storage.sync.set({ enabled: next });
    renderState(next);
    await notifyActiveTab(next);
  }
  getEnabled().then(renderState);
  toggleBtn.addEventListener("click", onToggle);
})();
